import 'package:flutter/material.dart';

import '../data/shop_data.dart';
import '../models/cake_shop.dart';
import '../theme/cake_theme.dart';
import '../widgets/shop_tile.dart';
import 'shop_details_screen.dart';

class DirectoryScreen extends StatefulWidget {
  const DirectoryScreen({
    super.key,
    required this.favorites,
    required this.onFavorite,
  });

  final Set<int> favorites;
  final ValueChanged<int> onFavorite;

  @override
  State<DirectoryScreen> createState() => _DirectoryScreenState();
}

class _DirectoryScreenState extends State<DirectoryScreen> {
  int _selectedTab = 0;
  String _query = '';

  void _openShop(CakeShop shop) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ShopDetailsScreen(
          shop: shop,
          isFavorite: widget.favorites.contains(shop.id),
          onFavorite: () {
            widget.onFavorite(shop.id);
            setState(() {});
          },
        ),
      ),
    ).then((_) { if (mounted) setState(() {}); });
  }

  @override
  Widget build(BuildContext context) {
    final shownShops = cakeShops.where((shop) {
      final matchesQuery = shop.name.toLowerCase().contains(_query.trim().toLowerCase());
      return matchesQuery && (_selectedTab == 0 || widget.favorites.contains(shop.id));
    }).toList(growable: false);

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Image.asset('assets/images/icon.png', width: 43, height: 43),
                        const SizedBox(width: 10),
                        const Expanded(
                          child: Text('CAKE SHOP', style: TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 1.6, color: CakeColors.ink,
                          )),
                        ),
                        IconButton(
                          tooltip: 'Favorites',
                          onPressed: () => setState(() => _selectedTab = 1),
                          icon: const Icon(Icons.favorite_border_rounded, color: CakeColors.red),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    Text(
                      _selectedTab == 0 ? 'Discover your\nsweet spot.' : 'Your favorite\ncake shops.',
                      style: Theme.of(context).textTheme.headlineLarge,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      _selectedTab == 0 ? 'Explore seven delightful cake shops.' : 'All the places you saved, in one place.',
                      style: const TextStyle(fontSize: 14, color: CakeColors.muted),
                    ),
                    const SizedBox(height: 25),
                    TextField(
                      onChanged: (text) => setState(() => _query = text),
                      textInputAction: TextInputAction.search,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search_rounded, color: CakeColors.red),
                        hintText: 'Search cake shops...',
                        hintStyle: TextStyle(color: CakeColors.muted),
                      ),
                    ),
                    const SizedBox(height: 29),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _selectedTab == 0 ? 'Featured shops' : 'Saved shops',
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                        ),
                        Text('${shownShops.length} shops', style: const TextStyle(color: CakeColors.muted)),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
            if (shownShops.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _selectedTab == 0 ? Icons.search_off_rounded : Icons.favorite_outline_rounded,
                          color: CakeColors.red,
                          size: 48,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _selectedTab == 0 ? 'No shops found' : 'No saved shops yet',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _selectedTab == 0 ? 'Try another name.' : 'Tap a heart to save a cake shop.',
                          style: const TextStyle(color: CakeColors.muted),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 26),
                sliver: SliverLayoutBuilder(
                  builder: (context, constraints) {
                    final width = constraints.crossAxisExtent;
                    final columns = width >= 800 ? 4 : width >= 560 ? 3 : 2;
                    return SliverGrid(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: columns,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 0.76,
                      ),
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          final shop = shownShops[index];
                          return ShopTile(
                            shop: shop,
                            isFavorite: widget.favorites.contains(shop.id),
                            onFavorite: () {
                              widget.onFavorite(shop.id);
                              setState(() {});
                            },
                            onTap: () => _openShop(shop),
                          );
                        },
                        childCount: shownShops.length,
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        height: 72,
        selectedIndex: _selectedTab,
        backgroundColor: Colors.white,
        indicatorColor: CakeColors.rose,
        onDestinationSelected: (index) => setState(() { _selectedTab = index; _query = ''; }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.cake_outlined), selectedIcon: Icon(Icons.cake), label: 'Explore'),
          NavigationDestination(icon: Icon(Icons.favorite_border_rounded), selectedIcon: Icon(Icons.favorite_rounded), label: 'Saved'),
        ],
      ),
    );
  }
}
