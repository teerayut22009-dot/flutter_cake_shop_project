import 'package:flutter/material.dart';

import '../models/cake_shop.dart';
import '../theme/cake_theme.dart';

class ShopTile extends StatelessWidget {
  const ShopTile({
    super.key,
    required this.shop,
    required this.onTap,
    required this.onFavorite,
    required this.isFavorite,
  });

  final CakeShop shop;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  final bool isFavorite;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: CakeColors.divider),
          boxShadow: const [BoxShadow(color: Color(0x0B3A2428), blurRadius: 24, offset: Offset(0, 7))],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Hero(
                    tag: shop.heroTag,
                    child: Image.asset(shop.cover, fit: BoxFit.cover),
                  ),
                  Positioned(
                    right: 9,
                    top: 9,
                    child: Material(
                      color: Colors.white.withValues(alpha: 0.93),
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: isFavorite ? 'Remove from favorites' : 'Save favorite',
                        onPressed: onFavorite,
                        iconSize: 20,
                        visualDensity: VisualDensity.compact,
                        icon: Icon(
                          isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                          color: CakeColors.red,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 8, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      shop.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, color: CakeColors.ink, fontSize: 14),
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded, color: CakeColors.red, size: 14),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
