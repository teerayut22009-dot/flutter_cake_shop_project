import 'package:flutter/material.dart';

class CakeColors {
  const CakeColors._();

  static const red = Color(0xFFBD2136);
  static const rose = Color(0xFFFFE9EB);
  static const parchment = Color(0xFFFFFAF8);
  static const ink = Color(0xFF2D2224);
  static const muted = Color(0xFF8C7A7D);
  static const divider = Color(0xFFF1E8E7);
}

ThemeData buildCakeTheme() {
  const radius = BorderRadius.all(Radius.circular(15));
  final scheme = ColorScheme.fromSeed(
    seedColor: CakeColors.red,
    primary: CakeColors.red,
    surface: CakeColors.parchment,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: CakeColors.parchment,
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontSize: 34, height: 1.15, fontWeight: FontWeight.w800, color: CakeColors.ink),
      headlineMedium: TextStyle(fontSize: 26, height: 1.2, fontWeight: FontWeight.w800, color: CakeColors.ink),
      titleLarge: TextStyle(fontSize: 21, height: 1.2, fontWeight: FontWeight.w700, color: CakeColors.ink),
      titleMedium: TextStyle(fontSize: 16, height: 1.2, fontWeight: FontWeight.w700, color: CakeColors.ink),
      bodyMedium: TextStyle(fontSize: 14, height: 1.4, color: CakeColors.ink),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: CakeColors.parchment,
      elevation: 0,
      centerTitle: false,
      foregroundColor: CakeColors.ink,
      scrolledUnderElevation: 0,
    ),
    cardTheme: const CardThemeData(
      surfaceTintColor: Colors.transparent,
      color: Colors.white,
      elevation: 0,
      margin: EdgeInsets.zero,
    ),
    inputDecorationTheme: const InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: radius, borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: radius, borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: radius, borderSide: BorderSide(color: CakeColors.red, width: 1.5)),
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: CakeColors.red,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ),
  );
}
