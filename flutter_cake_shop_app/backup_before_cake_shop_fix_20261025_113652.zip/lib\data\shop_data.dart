import '../models/cake_shop.dart';

const List<CakeShop> cakeShops = [
  CakeShop(
    id: 1,
    name: 'The.earlybake',
    cover: 'assets/images/ck01.png',
    photos: [
      'assets/images/s11.jpg',
      'assets/images/s12.jpg',
      'assets/images/s13.jpg',
    ],
  ),
  CakeShop(
    id: 2,
    name: 'Feelin.doughgood',
    cover: 'assets/images/ck02.png',
    photos: [
      'assets/images/s21.jpg',
      'assets/images/s22.jpg',
      'assets/images/s23.jpg',
    ],
  ),
  CakeShop(
    id: 3,
    name: 'C Belly',
    cover: 'assets/images/ck03.png',
    photos: [
      'assets/images/s31.jpg',
      'assets/images/s32.jpg',
      'assets/images/s33.jpg',
    ],
  ),
  CakeShop(
    id: 4,
    name: 'The Story Caker',
    cover: 'assets/images/ck04.png',
    photos: [
      'assets/images/s41.jpg',
      'assets/images/s42.jpg',
      'assets/images/s43.jpg',
    ],
  ),
  CakeShop(
    id: 5,
    name: 'Aob Auan',
    cover: 'assets/images/ck05.png',
    photos: [
      'assets/images/s51.jpg',
      'assets/images/s52.jpg',
      'assets/images/s53.jpg',
    ],
  ),
  CakeShop(
    id: 6,
    name: 'SamSuan',
    cover: 'assets/images/ck06.png',
    photos: [
      'assets/images/s61.jpg',
      'assets/images/s62.jpg',
      'assets/images/s63.jpg',
    ],
  ),
  CakeShop(
    id: 7,
    name: 'Cafe De Tu',
    cover: 'assets/images/ck07.png',
    photos: [
      'assets/images/s71.jpg',
      'assets/images/s72.jpg',
      'assets/images/s73.jpg',
    ],
  ),
];
