import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_cake_shop_project/data/cake_shop_data.dart';

void main() {
  test('ข้อมูลครบ 7 ร้านและมีรูปเค้ก 3 รูปต่อร้าน', () {
    expect(cakeShops.length, 7);
    expect(cakeShops.map((e) => e.name).toSet().length, 7);
    expect(cakeShops[3].name, 'Larna House');
    expect(cakeShops[3].phone, '023215995');
    for (final shop in cakeShops) {
      expect(shop.image1, startsWith('assets/images/'));
      expect(shop.image2, startsWith('assets/images/'));
      expect(shop.image3, startsWith('assets/images/'));
      expect(shop.coordinates.latitude, inInclusiveRange(-90, 90));
      expect(shop.coordinates.longitude, inInclusiveRange(-180, 180));
    }
  });
}
