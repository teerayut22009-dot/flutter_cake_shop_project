import 'package:latlong2/latlong.dart';

/// ข้อมูลตัวอย่างเพื่อการเรียนตาม requirement (ไม่ยืนยันว่าเป็นข้อมูลร้านจริง)
class CakeShop {
  const CakeShop({
    required this.name,
    required this.address,
    required this.phone,
    required this.image1,
    required this.image2,
    required this.image3,
    required this.description,
    required this.openCloseTime,
    required this.website,
    required this.facebook,
    required this.latitude,
    required this.longitude,
  });

  final String name;
  final String address;
  final String phone;
  final String image1;
  final String image2;
  final String image3;
  final String description;
  final String openCloseTime;
  final String website;
  final String facebook;
  final String latitude;
  final String longitude;

  LatLng get coordinates =>
      LatLng(double.parse(latitude), double.parse(longitude));
}
