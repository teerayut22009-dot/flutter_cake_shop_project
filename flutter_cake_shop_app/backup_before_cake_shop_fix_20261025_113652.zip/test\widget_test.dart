import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_cake_shop_app/main.dart';

void main() {
  testWidgets('welcome opens the cake shop gallery', (tester) async {
    await tester.pumpWidget(const CakeShopApp());
    expect(find.text('Life is better\nwith cake.'), findsOneWidget);
    await tester.tap(find.text('Explore cake shops'));
    await tester.pumpAndSettle();
    expect(find.text('Featured shops'), findsOneWidget);
    expect(find.text('The.earlybake'), findsOneWidget);
  });

  testWidgets('saved shops initially empty', (tester) async {
    await tester.pumpWidget(const CakeShopApp());
    await tester.tap(find.text('Explore cake shops'));
    await tester.pumpAndSettle();
    await tester.tap(find.byIcon(Icons.favorite_border_rounded).first);
    await tester.pumpAndSettle();
    expect(find.text('Saved shops'), findsOneWidget);
  });
}
