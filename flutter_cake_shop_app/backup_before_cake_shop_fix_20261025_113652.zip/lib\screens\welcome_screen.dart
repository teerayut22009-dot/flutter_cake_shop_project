import 'package:flutter/material.dart';

import '../theme/cake_theme.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key, required this.onStart});

  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/bg_welcome.png',
            fit: BoxFit.cover,
            alignment: Alignment.center,
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x11FFFFFF), Color(0x00FFFFFF), Color(0x550E090A)],
                stops: [0, 0.54, 1],
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(28, 42, 28, 28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Image.asset('assets/images/icon.png', width: 48, height: 48),
                      const SizedBox(width: 8),
                      const Text(
                        'CAKE SHOP',
                        style: TextStyle(
                          color: CakeColors.ink,
                          letterSpacing: 2.4,
                          fontWeight: FontWeight.w900,
                          fontSize: 19,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 52),
                  const Text(
                    'Life is better\nwith cake.',
                    style: TextStyle(
                      fontSize: 43,
                      height: 1.07,
                      letterSpacing: -1.7,
                      color: CakeColors.ink,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Find your next favorite cake,\none sweet shop at a time.',
                    style: TextStyle(fontSize: 15, height: 1.6, color: Color(0xFF655457)),
                  ),
                  const Spacer(),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: onStart,
                      iconAlignment: IconAlignment.end,
                      icon: const Icon(Icons.arrow_forward_rounded),
                      label: const Text('Explore cake shops', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    ),
                  ),
                  const SizedBox(height: 4),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
