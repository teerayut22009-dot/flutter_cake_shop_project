import 'package:flutter/material.dart';

import '../models/cake_shop.dart';
import '../theme/cake_theme.dart';
import 'photo_viewer_screen.dart';

class ShopDetailsScreen extends StatefulWidget {
  const ShopDetailsScreen({
    super.key,
    required this.shop,
    required this.isFavorite,
    required this.onFavorite,
  });

  final CakeShop shop;
  final bool isFavorite;
  final VoidCallback onFavorite;

  @override
  State<ShopDetailsScreen> createState() => _ShopDetailsScreenState();
}

class _ShopDetailsScreenState extends State<ShopDetailsScreen> {
  late bool _favorite;

  @override
  void initState() {
    super.initState();
    _favorite = widget.isFavorite;
  }

  void _toggleFavorite() {
    setState(() => _favorite = !_favorite);
    widget.onFavorite();
  }

  void _openImage(int initialIndex) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        pageBuilder: (_, animation, secondaryAnimation) => PhotoViewerScreen(
          shop: widget.shop,
          initialIndex: initialIndex,
        ),
        transitionDuration: const Duration(milliseconds: 230),
        transitionsBuilder: (context, animation, secondaryAnimation, child) => FadeTransition(opacity: animation, child: child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final shop = widget.shop;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          tooltip: 'Back',
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Shop details', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            tooltip: _favorite ? 'Remove from favorites' : 'Save favorite',
            onPressed: _toggleFavorite,
            icon: Icon(_favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: CakeColors.red),
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: AspectRatio(
                      aspectRatio: 1.24,
                      child: Hero(
                        tag: shop.heroTag,
                        child: Image.asset(shop.cover, fit: BoxFit.cover),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: Text(shop.name, style: Theme.of(context).textTheme.headlineMedium)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                        decoration: BoxDecoration(color: CakeColors.rose, borderRadius: BorderRadius.circular(100)),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.collections_outlined, size: 15, color: CakeColors.red),
                            SizedBox(width: 5),
                            Text('3 photos', style: TextStyle(fontSize: 12, color: CakeColors.red, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'A little something sweet, just for you.',
                    style: TextStyle(color: CakeColors.muted, fontSize: 14),
                  ),
                  const SizedBox(height: 30),
                  Row(
                    children: [
                      Expanded(child: Text('Cake gallery', style: Theme.of(context).textTheme.titleLarge)),
                      const Text('Tap to view', style: TextStyle(color: CakeColors.muted, fontSize: 12)),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _GalleryPicture(
                    imagePath: shop.photos[0],
                    heroTag: 'photo-${shop.id}-0',
                    height: 215,
                    onTap: () => _openImage(0),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _GalleryPicture(
                          imagePath: shop.photos[1],
                          heroTag: 'photo-${shop.id}-1',
                          height: 148,
                          onTap: () => _openImage(1),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _GalleryPicture(
                          imagePath: shop.photos[2],
                          heroTag: 'photo-${shop.id}-2',
                          height: 148,
                          onTap: () => _openImage(2),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 27),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => _openImage(0),
                      icon: const Icon(Icons.photo_library_outlined),
                      label: const Text('View all cake photos', style: TextStyle(fontWeight: FontWeight.w700)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GalleryPicture extends StatelessWidget {
  const _GalleryPicture({
    required this.imagePath,
    required this.height,
    required this.heroTag,
    required this.onTap,
  });

  final String imagePath;
  final double height;
  final String heroTag;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'Open cake photo',
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(17),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(17),
          child: SizedBox(
            height: height,
            width: double.infinity,
            child: Hero(
              tag: heroTag,
              child: Image.asset(imagePath, fit: BoxFit.cover),
            ),
          ),
        ),
      ),
    );
  }
}
